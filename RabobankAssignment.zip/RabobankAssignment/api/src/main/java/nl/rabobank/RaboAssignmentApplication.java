package nl.rabobank;

import java.util.Arrays;
import java.util.List;
import lombok.extern.slf4j.Slf4j;
import nl.rabobank.account.Account;
import nl.rabobank.account.PaymentAccount;
import nl.rabobank.account.SavingsAccount;
import nl.rabobank.authorizations.PowerOfAttorney;
import nl.rabobank.mongo.MongoConfiguration;
import nl.rabobank.mongo.repository.AccountRepository;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.index.Index;

@Slf4j
@SpringBootApplication
@Import(MongoConfiguration.class)
public class RaboAssignmentApplication
{
    @Autowired
    private AccountRepository accountRepository;
    @Autowired
    private MongoTemplate mongoTemplate;

    public static void main(final String[] args)
    {
        SpringApplication.run(RaboAssignmentApplication.class, args);
    }
    /**
     * Init Bean to load some example accounts
     */
    @Bean
    InitializingBean addAccounts() {
        return () -> accountRepository.saveAll(listAccounts());
    }

    @Bean
    InitializingBean createIndexes() {
        return () -> {
            mongoTemplate.indexOps(PowerOfAttorney.class).ensureIndex(
                    new Index().named("roleind_").
                            on("grantorName", Direction.ASC).
                            on("granteeName", Direction.ASC).
                            on("account", Direction.ASC).
                            on("authorization", Direction.ASC).unique());

            mongoTemplate.indexOps(Account.class)
                    .ensureIndex(new Index().named("acno_").on("accountNumber", Direction.ASC).unique());
        };
    }

    private List<Account> listAccounts() {
        return Arrays.asList(getSavingAccount(), getPaymentAccount());
    }

    private SavingsAccount getSavingAccount(){
        return new SavingsAccount("NL23ABNA12345", "Sonam", 1000D);
    }

    private PaymentAccount getPaymentAccount(){
        return new PaymentAccount("NL23ARABO12345", "Raju", 200D);
    }
}
