package nl.rabobank.controller;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.rabobank.exception.AccountNotFoundException;
import nl.rabobank.exception.GrantorNoRightsException;
import nl.rabobank.exception.AuthorizationAlreadyGrantedException;
import nl.rabobank.model.rest.AccountsAccessableResponse;
import nl.rabobank.model.rest.PowerOfAttorneyRequest;
import nl.rabobank.service.AuthorizationService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

/**
 * RabobankAssignmentController - the Rest API controller, it provide endpoints to perform the below 2 actions:
 * Users must be able to create write or read access for payments and savings accounts (/grantAccess)
 * Users need to be able to retrieve a list of accounts they have read or write access for  (/getAccess)
 */

@Slf4j
@RestController
@RequiredArgsConstructor
public class RabobankAssignmentController {

    @Resource
    private final AuthorizationService authorizationService;

    /**
     * @RequestBody PowerOfAttorneyRequest request
     */
    @PostMapping("/grantAccess")
    @ResponseStatus(HttpStatus.CREATED)
    public void grantPowerOfAttorney(@RequestBody PowerOfAttorneyRequest request)
            throws AccountNotFoundException, GrantorNoRightsException, AuthorizationAlreadyGrantedException {
        authorizationService.grantAccessToGrantee(request);
    }

    /**
     * @param user user
     * @return AccountsAccessableResponse with 2 lists for READ and WRITE accounts.
     */
    @GetMapping("/getAccess")
    public AccountsAccessableResponse getAccessibleAccounts(@RequestParam("user") String user) {
        return authorizationService.getAccessibleAccounts(user);
    }
}
