package nl.rabobank.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown when grantor has no rights to the account.
 */
@ResponseStatus(HttpStatus.FORBIDDEN)
public class GrantorNoRightsException extends Exception {

    public GrantorNoRightsException(String message) {
        super(message);
    }
}