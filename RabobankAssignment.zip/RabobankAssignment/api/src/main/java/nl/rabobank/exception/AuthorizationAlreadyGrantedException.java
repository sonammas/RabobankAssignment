package nl.rabobank.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

/**
 * Thrown when Authorization has Already been Granted
 */
@ResponseStatus(HttpStatus.EXPECTATION_FAILED)
public class AuthorizationAlreadyGrantedException extends Exception {
    public AuthorizationAlreadyGrantedException(String message) {
        super(message);
    }}
