package nl.rabobank.service;

import nl.rabobank.account.Account;

import java.util.Optional;

public interface AccountService {
    Optional<Account> findByAccountNumber(String accountNumber);
}
