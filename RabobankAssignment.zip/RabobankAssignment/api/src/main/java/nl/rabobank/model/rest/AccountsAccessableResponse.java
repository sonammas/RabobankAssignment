package nl.rabobank.model.rest;

import java.util.List;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.Setter;
import nl.rabobank.account.Account;

/**
 * response of accounts which are accessible by the user
 */
@Getter
@Setter
@AllArgsConstructor
public class AccountsAccessableResponse {

    List<Account> readAccessAccounts;
    List<Account> writeAccessAccounts;
}