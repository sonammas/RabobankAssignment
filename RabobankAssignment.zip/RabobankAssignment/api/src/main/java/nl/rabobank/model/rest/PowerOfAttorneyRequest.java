package nl.rabobank.model.rest;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;
import nl.rabobank.authorizations.Authorization;

@Getter
@Setter
@AllArgsConstructor
@NoArgsConstructor
@Builder
@JsonIgnoreProperties(ignoreUnknown = true)
public class PowerOfAttorneyRequest {

    private String granteeName;
    private String grantorName;
    private String accountNumber;
    private Authorization authorization;

}

