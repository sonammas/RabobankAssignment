package nl.rabobank.service;

import java.util.Optional;
import java.util.stream.Collectors;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import nl.rabobank.account.Account;
import nl.rabobank.authorizations.Authorization;
import nl.rabobank.authorizations.PowerOfAttorney;
import nl.rabobank.exception.AccountNotFoundException;
import nl.rabobank.exception.GrantorNoRightsException;
import nl.rabobank.exception.AuthorizationAlreadyGrantedException;
import nl.rabobank.model.rest.AccountsAccessableResponse;
import nl.rabobank.model.rest.PowerOfAttorneyRequest;
import nl.rabobank.mongo.repository.PowerOfAttorneyRepository;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
@Slf4j
public class AuthorizationServiceImpl implements AuthorizationService {

    private final PowerOfAttorneyRepository powerOfAttorneyRepository;
    private final AccountService accountService;

    /**
     * Validate and save the POA
     *
     * @param request
     * @throws AccountNotFoundException if account not found
     * @throws GrantorNoRightsException if no rights for Grantor
     * @throws AuthorizationAlreadyGrantedException if role already exists
     */
    public void grantAccessToGrantee(PowerOfAttorneyRequest request) throws AccountNotFoundException, GrantorNoRightsException, AuthorizationAlreadyGrantedException {
        log.info("Recieved Request for granting Power of attorney {}", request);
        Optional<Account> account = accountService.findByAccountNumber(request.getAccountNumber());
        if (account.isPresent()) {
            if (!hasGrantorRights(account.get(), request)) {
                log.error("Grantor {} does not have right to give access to grantee {}", request.getGrantorName(), request.getGranteeName());
                throw new GrantorNoRightsException("Grantor " + request.getGrantorName()
                        + " has no rights on account number: " + request.getAccountNumber());
            } else {
                insertdatabaseRecords(request);
            }
        } else {
            throw new AccountNotFoundException("No Account Found for : " + request.getAccountNumber());
        }
    }

    private boolean hasGrantorRights(Account account, PowerOfAttorneyRequest request) {
        return account.getAccountHolderName().equals(request.getGrantorName());
    }

    private void insertdatabaseRecords(PowerOfAttorneyRequest request) throws AuthorizationAlreadyGrantedException {
        PowerOfAttorney powerOfAttorney = map(request);
        try {
            powerOfAttorneyRepository.save(powerOfAttorney);
        } catch (DuplicateKeyException ex) {
            log.error("Grantee already had the Authorization role");
            throw new AuthorizationAlreadyGrantedException("Given Authorization already granted");
        }
    }

    private PowerOfAttorney map(PowerOfAttorneyRequest powerOfAttorney) {
        return PowerOfAttorney.builder()
                .granteeName(powerOfAttorney.getGranteeName())
                .grantorName(powerOfAttorney.getGrantorName())
                .authorization(powerOfAttorney.getAuthorization())
                .account(accountService.findByAccountNumber(powerOfAttorney.getAccountNumber()).orElse(null))
                .build();
    }

    /**
     * @param user user
     * @return AccountsAccessableResponse with two lists for READ and WRITE
     */
    @Override
    public AccountsAccessableResponse getAccessibleAccounts(String user) {
        return new AccountsAccessableResponse(
                powerOfAttorneyRepository
                        .findAllByGranteeNameAndAuthorization(user, Authorization.READ).stream()
                        .map(PowerOfAttorney::getAccount)
                        .collect(Collectors.toList()),
                powerOfAttorneyRepository
                        .findAllByGranteeNameAndAuthorization(user, Authorization.WRITE).stream()
                        .map(PowerOfAttorney::getAccount)
                        .collect(Collectors.toList()));
    }

}
