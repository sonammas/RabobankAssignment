package nl.rabobank.service;

import nl.rabobank.exception.AccountNotFoundException;
import nl.rabobank.exception.GrantorNoRightsException;
import nl.rabobank.exception.AuthorizationAlreadyGrantedException;
import nl.rabobank.model.rest.AccountsAccessableResponse;
import nl.rabobank.model.rest.PowerOfAttorneyRequest;

public interface AuthorizationService {

    void grantAccessToGrantee(PowerOfAttorneyRequest request) throws AccountNotFoundException, GrantorNoRightsException, AuthorizationAlreadyGrantedException;

    AccountsAccessableResponse getAccessibleAccounts(String userName);
}

