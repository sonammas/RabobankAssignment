package nl.rabobank;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;

import nl.rabobank.mongo.repository.AccountRepository;
import nl.rabobank.service.AccountService;
import nl.rabobank.service.AccountServiceImpl;
import org.junit.jupiter.api.Test;

public class AccountServiceTest {

    private AccountRepository accountRepository = mock(AccountRepository.class);
    private AccountService service = new AccountServiceImpl(accountRepository);

    @Test
    public void itShouldFindByAccountNumberFromRepo() {
        service.findByAccountNumber("1234");
        verify(accountRepository, times(1)).findByAccountNumber("1234");
    }
}