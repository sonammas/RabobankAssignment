package nl.rabobank;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.  times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.List;
import java.util.Optional;
import nl.rabobank.account.Account;
import nl.rabobank.account.SavingsAccount;
import nl.rabobank.authorizations.Authorization;
import nl.rabobank.authorizations.PowerOfAttorney;
import nl.rabobank.exception.AccountNotFoundException;

import nl.rabobank.exception.AuthorizationAlreadyGrantedException;
import nl.rabobank.exception.GrantorNoRightsException;
import nl.rabobank.model.rest.AccountsAccessableResponse;
import nl.rabobank.model.rest.PowerOfAttorneyRequest;
import nl.rabobank.mongo.repository.PowerOfAttorneyRepository;
import nl.rabobank.service.AccountService;
import nl.rabobank.service.AuthorizationService;
import nl.rabobank.service.AuthorizationServiceImpl;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

public class AuthorizationServiceTest {

    private PowerOfAttorneyRepository powerOfAttorneyRepository = mock(PowerOfAttorneyRepository.class);

    private AccountService accountService = mock(AccountService.class);

    private AuthorizationService service = new AuthorizationServiceImpl(powerOfAttorneyRepository, accountService);

    @Test
    public void itShouldPostPowerOfAttorneyTest() throws AccountNotFoundException, GrantorNoRightsException, AuthorizationAlreadyGrantedException {
        when(accountService.findByAccountNumber(inputPOA().getAccountNumber())).thenReturn(givenAccount("Sonam"));
        //when
        service.grantAccessToGrantee(inputPOA());

        //then
        verify(powerOfAttorneyRepository, times(1)).save(any(PowerOfAttorney.class));
    }

    @Test
    public void itShouldNotPostPowerOfAttorneyWhenAccountNotFound() {
        //given
        Assertions.assertThrows((AccountNotFoundException.class), () -> {
            when(accountService.findByAccountNumber(inputPOA().getAccountNumber())).thenReturn(Optional.empty());
            //when
            service.grantAccessToGrantee(inputPOA());

            //then
            verify(powerOfAttorneyRepository, never()).save(any(PowerOfAttorney.class));
        });
    }

    @Test
    public void itShouldGetAccessibleAccountsForUser() {
        //given
        when(powerOfAttorneyRepository.
                findAllByGranteeNameAndAuthorization("Sonam", Authorization.READ)).
                thenReturn(List.of(outputPOA()));
        //when
        AccountsAccessableResponse res = service.getAccessibleAccounts("Sonam");
        //then
        assertEquals(0, res.getWriteAccessAccounts().size());
        assertEquals(1, res.getReadAccessAccounts().size());
    }

    private PowerOfAttorneyRequest inputPOA() {
        return PowerOfAttorneyRequest.builder()
                .accountNumber("NLABNA1234")
                .authorization(Authorization.READ)
                .granteeName("Raju")
                .grantorName("Sonam")
                .build();
    }

    private PowerOfAttorney outputPOA() {
        return PowerOfAttorney.builder()
                .account(givenAccount("Sonam").get())
                .authorization(Authorization.READ)
                .granteeName("Raju")
                .grantorName("Sonam")
                .build();
    }

    private Optional<Account> givenAccount(String accHolderName) {
        return Optional.of(new SavingsAccount("NLABNA1234", accHolderName, 1000D));
    }
}
