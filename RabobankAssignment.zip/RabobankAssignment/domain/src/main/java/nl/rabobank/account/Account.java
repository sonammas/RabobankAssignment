package nl.rabobank.account;

public interface Account
{
    String getAccountNumber();
    String getAccountHolderName();
    Double getBalance();
}
