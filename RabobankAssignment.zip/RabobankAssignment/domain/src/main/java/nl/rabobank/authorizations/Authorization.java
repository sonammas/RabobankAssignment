package nl.rabobank.authorizations;

public enum Authorization
{
    READ,
    WRITE
}
